=== Dobby - Html Compress ===
Contributors: vtrois
Tags: dobby, html, compress
Requires at least: 4.5
Tested up to: 4.9
Stable tag: 4.9
License: GNU General Public License v3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==
Used to compress the page size and improve loading speed.

== Changelog ==

= 1.0 =
* Create a stable version.